﻿Ninja yaya = new Ninja();
Buffet Buff = new Buffet();
Food food = Buff.Serve();
yaya.Eat(food);
Console.WriteLine(yaya.IsFull);